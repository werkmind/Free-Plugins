<?php

if (!defined('ABSPATH')) {
	exit;
}

final class WSF_ACFE_Grouping_Parser {

	/**
	 * ACF choices usually come as:
	 * [
	 *   'b' => 'B',
	 *   'be' => 'BE',
	 *   '## Europa' => '## Europa'   // or sometimes label/value variations
	 * ]
	 *
	 * We normalize that into WS Form groups.
	 */
	public static function parse_choices(array $choices) {
		$groups = [];
		$current_group = [
			'label' => __('Options', 'wsf-acfe-grouping'),
			'rows'  => [],
		];

		foreach ($choices as $value => $label) {
			$value = is_string($value) ? trim($value) : $value;
			$label = is_string($label) ? trim($label) : $label;

			$group_label = self::extract_group_label($value, $label);

			if ($group_label !== null) {
				if (!empty($current_group['rows'])) {
					$groups[] = $current_group;
				}

				$current_group = [
					'label' => $group_label,
					'rows'  => [],
				];

				continue;
			}

			$current_group['rows'][] = [
				'value' => $value,
				'label' => $label,
			];
		}

		if (!empty($current_group['rows'])) {
			$groups[] = $current_group;
		}

		return $groups;
	}

	protected static function extract_group_label($value, $label) {
		foreach ([$value, $label] as $candidate) {
			if (!is_string($candidate)) {
				continue;
			}

			if (preg_match('/^\s*##\s*(.+?)\s*$/', $candidate, $matches)) {
				return trim($matches[1]);
			}
		}

		return null;
	}
}