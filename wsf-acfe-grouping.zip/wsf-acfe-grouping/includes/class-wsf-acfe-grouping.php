<?php

if (!defined('ABSPATH')) {
	exit;
}

class WSF_ACFE_Grouping {

	const META_KEY = 'acfe_hash_grouping';

	public function __construct() {
		add_filter('wsf_pre_render', [$this, 'pre_render'], 10, 2);
		add_filter('wsf_config_field_types', [$this, 'config_field_types'], 10, 1);
		add_filter('wsf_config_meta_keys', [$this, 'config_meta_keys'], 10, 2);
		add_filter('wsf_config_options', [$this, 'config_options'], 10, 1);
		add_filter('wsf_settings_static', [$this, 'settings_static'], 10, 2);
		add_filter('plugin_action_links_' . WSF_ACFE_GROUPING_PLUGIN_BASENAME, [$this, 'plugin_action_links'], 10, 1);
	}

	public function config_options($options) {
		$options['acfe_grouping'] = [
			'label'  => __('ACFE ## Grouping', 'wsf-acfe-grouping'),
			'fields' => [
				'acfe_grouping_disclaimer' => [
					'label' => __('Disclaimer', 'wsf-acfe-grouping'),
					'type'  => 'static',
				],
				'acfe_grouping_version' => [
					'label' => __('Add-on Version', 'wsf-acfe-grouping'),
					'type'  => 'static',
				],
			],
		];
		return $options;
	}

	public function plugin_action_links($links) {
		array_unshift(
			$links,
			sprintf(
				'<a href="%s">%s</a>',
				esc_url(WS_Form_Common::get_admin_url('ws-form-settings', false, 'tab=acfe_grouping')),
				__('Settings', 'wsf-acfe-grouping')
			)
		);
		return $links;
	}

	public function settings_static($value, $field) {
		if ($field === 'acfe_grouping_disclaimer') {
			return '<div class="wsf-notice wsf-notice-info" style="margin: 1em 0; padding: 1em; background: #f0f6fc; border-left: 4px solid #2271b1; font-size: 13px; line-height: 1.5;">'
				. '<p style="margin: 0 0 0.5em;"><strong>' . esc_html__('Disclaimer', 'wsf-acfe-grouping') . '</strong></p>'
				. '<p style="margin: 0;">'
				. esc_html__('This Plugin was made using Artificial Intelligence in combination with a Junior Developer. There could be bugs. We encourage you to use it on a staging site and NOT on a live environment!', 'wsf-acfe-grouping')
				. ' '
				. esc_html__('This Plugin was tested with Advanced Custom Fields PRO 6.7.0.2 and Advanced Custom Fields: Extended PRO 0.2.2.2 in combination with WS Form Pro 1.10.80 and WS Form Pro - Post Management 1.6.12 last.', 'wsf-acfe-grouping')
				. ' '
				. esc_html__('Use at your own risk.', 'wsf-acfe-grouping')
				. ' '
				. sprintf(
					/* translators: %s: link to werkmind.com */
					esc_html__('If you like this small Plugin we would love to hear your feedback on it over at %s.', 'wsf-acfe-grouping'),
					'<a href="https://werkmind.com" target="_blank" rel="noopener noreferrer">werkmind.com</a>'
				)
				. ' '
				. esc_html__('Thanks for using this :)', 'wsf-acfe-grouping')
				. '</p></div>';
		}
		if ($field === 'acfe_grouping_version') {
			return WSF_ACFE_GROUPING_VERSION;
		}
		return $value;
	}

	public function config_meta_keys($meta_keys, $form_id) {
		$meta_keys[self::META_KEY] = [
			'label'     => __('Use ACFE ## Grouping', 'wsf-acfe-grouping'),
			'type'      => 'checkbox',
			'default'   => '',
			'help'      => __('Parses ACF Extended choice headings like ## Group and renders them as WS Form groups.', 'wsf-acfe-grouping'),
			'condition' => [
				[
					'logic'     => '==',
					'meta_key'  => 'data_source_id',
					'meta_value' => 'acf',
				],
			],
		];
		return $meta_keys;
	}

	public function config_field_types($field_types) {
		$tab_map = [
			'checkbox'       => 'checkboxes',
			'select'         => 'options',
			'radio'          => 'radios',
			'price_checkbox' => 'checkboxes',
			'price_select'   => 'options',
			'price_radio'    => 'radios',
		];

		foreach ($field_types as $group_key => &$group) {
			if (empty($group['types']) || !is_array($group['types'])) {
				continue;
			}
			foreach ($group['types'] as $type_key => &$type_config) {
				if (!isset($tab_map[$type_key])) {
					continue;
				}
				$tab_key = $tab_map[$type_key];
				if (empty($type_config['fieldsets'][$tab_key]['fieldsets'])) {
					continue;
				}
				foreach ($type_config['fieldsets'][$tab_key]['fieldsets'] as &$fieldset) {
					if (($fieldset['label'] ?? '') !== 'Cascading') {
						continue;
					}
					if (!in_array(self::META_KEY, $fieldset['meta_keys'], true)) {
						$fieldset['meta_keys'][] = self::META_KEY;
					}
					break;
				}
			}
		}

		return $field_types;
	}

	public function pre_render($form, $preview) {
		$groups = is_array($form) ? ($form['groups'] ?? []) : ($form->groups ?? []);
		if (!is_array($groups)) {
			return $form;
		}

		foreach ($groups as &$group) {
			$sections = is_array($group) ? ($group['sections'] ?? []) : ($group->sections ?? []);
			if (!is_array($sections)) {
				continue;
			}

			foreach ($sections as &$section) {
				$fields = is_array($section) ? ($section['fields'] ?? []) : ($section->fields ?? []);
				if (!is_array($fields)) {
					continue;
				}

				foreach ($fields as &$field) {
					$this->maybe_transform_field($field);
				}
			}
		}

		return $form;
	}

	protected function acf_choices_have_hash_grouping(array $choices) {
		foreach ($choices as $value => $label) {
			foreach ([$value, $label] as $candidate) {
				if (is_string($candidate) && preg_match('/^\s*##\s/', $candidate)) {
					return true;
				}
			}
		}
		return false;
	}

	protected function get_prop($obj, $key, $default = null) {
		if (is_array($obj)) {
			return $obj[$key] ?? $default;
		}
		return $obj->$key ?? $default;
	}

	protected function set_field_meta(&$field, $key, $value) {
		if (is_array($field)) {
			if (!isset($field['meta'])) {
				$field['meta'] = [];
			}
			$field['meta'][$key] = $value;
		} else {
			if (!isset($field->meta)) {
				$field->meta = new \stdClass();
			}
			$field->meta->$key = $value;
		}
	}

	protected function maybe_transform_field(&$field) {
		$type = $this->get_prop($field, 'type');
		$meta = $this->get_prop($field, 'meta');

		if (empty($type) || $meta === null || (!is_array($meta) && !is_object($meta))) {
			return;
		}

		if (!in_array($type, ['select', 'checkbox', 'radio', 'price_select', 'price_checkbox', 'price_radio'], true)) {
			return;
		}

		if ($this->get_prop($meta, self::META_KEY) !== 'on') {
			return;
		}

		if (
			$this->get_prop($meta, 'data_source_id') !== 'acf' ||
			empty($this->get_prop($meta, 'data_source_acf_field_key'))
		) {
			return;
		}

		$acf_field_key = $this->get_prop($meta, 'data_source_acf_field_key');
		$acf_field = function_exists('acf_get_field') ? acf_get_field($acf_field_key) : false;

		if (!$acf_field || empty($acf_field['choices']) || !is_array($acf_field['choices'])) {
			return;
		}

		if (!$this->acf_choices_have_hash_grouping($acf_field['choices'])) {
			return;
		}

		$parsed_groups = WSF_ACFE_Grouping_Parser::parse_choices($acf_field['choices']);

		if (empty($parsed_groups)) {
			return;
		}

		$data_grid_key = $this->get_data_grid_key($type);
		if (!$data_grid_key) {
			return;
		}

		$this->set_field_meta($field, $data_grid_key, $this->build_data_grid($field, $parsed_groups));
	}

	protected function get_data_grid_key($field_type) {
		switch ($field_type) {
			case 'select':
				return 'data_grid_select';
			case 'checkbox':
				return 'data_grid_checkbox';
			case 'radio':
				return 'data_grid_radio';
			case 'price_select':
				return 'data_grid_select_price';
			case 'price_checkbox':
				return 'data_grid_checkbox_price';
			case 'price_radio':
				return 'data_grid_radio_price';
		}
		return false;
	}

	protected function build_data_grid($field, array $parsed_groups) {
		$type = $this->get_prop($field, 'type');
		$is_price = in_array($type, ['price_select', 'price_checkbox', 'price_radio'], true);

		$group_rows = [];
		$row_id = 1;

		foreach ($parsed_groups as $group) {
			$rows = [];

			foreach ($group['rows'] as $choice) {
				$data = [(string) $choice['value'], (string) $choice['label']];
				if ($is_price) {
					$data[] = '0';
				}
				$rows[] = [
					'id'       => $row_id++,
					'default'  => false,
					'required' => false,
					'disabled' => false,
					'hidden'   => false,
					'data'     => $data,
				];
			}

			$group_rows[] = [
				'label'        => $group['label'],
				'page'         => 0,
				'disabled'     => '',
				'mask_group'   => 'on',
				'label_render' => 'on',
				'rows'         => $rows,
			];
		}

		$columns = [
			['id' => 0, 'label' => 'Value'],
			['id' => 1, 'label' => 'Label'],
		];
		if ($is_price) {
			$columns[] = ['id' => 2, 'label' => 'Price'];
		}

		return [
			'rows_per_page' => 10,
			'group_index'   => 0,
			'default'       => [],
			'columns'       => $columns,
			'groups'        => $group_rows,
		];
	}
}
