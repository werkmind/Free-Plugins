<?php

/**
 * @link              https://werkmind.com
 * @since             1.0.0
 * @package           WSF_ACFE_Grouping
 *
 * @wordpress-plugin
 * Plugin Name:       WS Form PRO - ACFE ## Grouping
 * Description:       ACFE ## Grouping add-on for WS Form PRO. Parses ACF Extended choice headings (## Group) and renders them as optgroups/fieldsets.
 * Version:           1.0.0 alpha
 * Requires at least: 5.4
 * Requires PHP:      7.2
 * License:           GPLv3 or later
 * License URI:       https://www.gnu.org/licenses/gpl-3.0.html
 * Author:            Werkmind
 * Author URI:        https://werkmind.com/
 * Text Domain:       wsf-acfe-grouping
 * Domain Path:       /languages
 */

if (!defined('ABSPATH')) {
	exit;
}

define('WSF_ACFE_GROUPING_PLUGIN_ROOT_FILE', __FILE__);
define('WSF_ACFE_GROUPING_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('WSF_ACFE_GROUPING_VERSION', '1.0.0 alpha');

class WSF_ACFE_Grouping_Add_On {

	const WS_FORM_PRO_ID        = 'ws-form-pro/ws-form.php';
	const WS_FORM_PRO_VERSION_MIN = '1.8.143';

	public function __construct() {
		if (!function_exists('is_plugin_active')) {
			include_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		add_action('plugins_loaded', [$this, 'plugins_loaded'], 20);
	}

	public function plugins_loaded() {
		if ($this->is_dependency_ok()) {
			new WSF_ACFE_Grouping();
		} else {
			$this->dependency_error();
			if (isset($_GET['activate'])) {
				unset($_GET['activate']);
			}
		}
	}

	public function activate() {
		if (!$this->is_dependency_ok()) {
			$this->dependency_error();
		}
	}

	public function is_dependency_ok() {
		if (!defined('WS_FORM_VERSION')) {
			return false;
		}
		return (
			is_plugin_active(self::WS_FORM_PRO_ID) &&
			version_compare(WS_FORM_VERSION, self::WS_FORM_PRO_VERSION_MIN, '>=')
		);
	}

	public function dependency_error() {
		add_action('after_plugin_row_' . plugin_basename(__FILE__), [$this, 'dependency_error_notification'], 10, 2);
	}

	public function dependency_error_notification($file, $plugin) {
		if (!current_user_can('update_plugins')) {
			return;
		}
		if ($file !== plugin_basename(__FILE__)) {
			return;
		}
		$message = sprintf(
			/* translators: 1: WS Form PRO link, 2: minimum version */
			__('This add-on requires %1$s (version %2$s or later) to be installed and activated.', 'wsf-acfe-grouping'),
			'<a href="https://wsform.com?utm_source=ws_form_pro&utm_medium=plugins" target="_blank">WS Form PRO</a>',
			self::WS_FORM_PRO_VERSION_MIN
		);
		echo '<tr class="plugin-update-tr"><td colspan="3" class="plugin-update colspanchange"><div class="update-message notice inline notice-error notice-alt"><p>' . wp_kses_post($message) . '</p></div></td></tr>';
	}
}

$wsf_acfe_grouping_addon = new WSF_ACFE_Grouping_Add_On();
register_activation_hook(__FILE__, [$wsf_acfe_grouping_addon, 'activate']);

add_action('wsf_plugins_loaded', function () {
	require_once __DIR__ . '/includes/parser.php';
	require_once __DIR__ . '/includes/class-wsf-acfe-grouping.php';
});
